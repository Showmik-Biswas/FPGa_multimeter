`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////

// DIGIT_PERIOD = 125000 cycles -> 100Hz refresh (100MHz / 125000 / 8)
// No derived clock needed anywhere.
////////////////////////////////////////////////////////////////////////////////
module DigitToSeg(
    input  [3:0] in1, in2, in3, in4, in5, in6, in7, in8,
    input        mclk,        // Connect to CLK100MHZ directly
    output reg [7:0] an,
    output reg [6:0] seg,
    output reg       dp
);

    // ------------------------------------------------------------------
    // 100MHz clock এ 100Hz refresh
    // প্রতি digit: 125,000 cycles = 1.25ms
    // Full refresh: 8 x 1.25ms = 10ms = 100Hz
    // ------------------------------------------------------------------
    localparam DIGIT_PERIOD = 125000;

    reg [16:0] period_cnt = 0;  // 17-bit (max 131071, enough for 125000)
    reg [2:0]  digit_cnt  = 0;  // 0 to 7

    always @(posedge mclk) begin
        if (period_cnt == DIGIT_PERIOD - 1) begin
            period_cnt <= 0;
            digit_cnt  <= digit_cnt + 1;
        end else
            period_cnt <= period_cnt + 1;
    end

    // ------------------------------------------------------------------
    // Digit data select (mux)
    // ------------------------------------------------------------------
    reg [3:0] digit_data;
    always @(*) begin
        case (digit_cnt)
            3'd0: digit_data = in1;
            3'd1: digit_data = in2;
            3'd2: digit_data = in3;
            3'd3: digit_data = in4;
            3'd4: digit_data = in5;
            3'd5: digit_data = in6;
            3'd6: digit_data = in7;
            3'd7: digit_data = in8;
            default: digit_data = 4'hA;
        endcase
    end

    // ------------------------------------------------------------------
    // 7-segment decode (active LOW, 0=ON 1=OFF)
    // default=7'b1111111 -> all OFF, no floating node
    // ------------------------------------------------------------------
    reg [6:0] seg_next;
    always @(*) begin
        case (digit_data)
            4'h0: seg_next = 7'b1000000;
            4'h1: seg_next = 7'b1111001;
            4'h2: seg_next = 7'b0100100;
            4'h3: seg_next = 7'b0110000;
            4'h4: seg_next = 7'b0011001;
            4'h5: seg_next = 7'b0010010;
            4'h6: seg_next = 7'b0000010;
            4'h7: seg_next = 7'b1111000;
            4'h8: seg_next = 7'b0000000;
            4'h9: seg_next = 7'b0010000;
            
            4'hA: seg_next = 7'b1111111; // blank
            4'hB: seg_next = 7'b1000001; // V/U
            4'hC: seg_next = 7'b1000110; // C
            4'hD: seg_next = 7'b0001000; // R
            4'hE: seg_next = 7'b0000110; // E
            4'hF: seg_next = 7'b0001110; // F
            default: seg_next = 7'b1111111;
        endcase
    end

    // ------------------------------------------------------------------
    // Anode decode (active LOW, one-hot)
    // default=8'hFF -> ALL OFF, no floating node
    // ------------------------------------------------------------------
    reg [7:0] an_next;
    always @(*) begin
        an_next = 8'b1111_1111;
        case (digit_cnt)
            3'd0: an_next = 8'b1111_1110;
            3'd1: an_next = 8'b1111_1101;
            3'd2: an_next = 8'b1111_1011;
            3'd3: an_next = 8'b1111_0111;
            3'd4: an_next = 8'b1110_1111;
            3'd5: an_next = 8'b1101_1111;
            3'd6: an_next = 8'b1011_1111;
            3'd7: an_next = 8'b0111_1111;
        endcase
    end

    // Decimal point: digit 4 (in5) এ ON -> X.XXX format
    wire dp_next = (digit_cnt == 3'd4) ? 1'b0 : 1'b1;

    always @(posedge mclk) begin
        seg <= seg_next;
        an  <= an_next;
        dp  <= dp_next;
    end

endmodule