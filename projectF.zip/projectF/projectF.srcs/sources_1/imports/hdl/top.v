`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Voltage / Current / Resistance XADC display - Nexys A7
//
// Display : X.XXX format on 7-segment (unchanged)
// UART    : 4 digits + unit, no decimal point
//           e.g. "0332V\r\n"  "0162C\r\n"  "0889R\r\n"

////////////////////////////////////////////////////////////////////////////////
module XADCdemo(
   input CLK100MHZ,
   input vauxp2,  input vauxn2,
   input vauxp3,  input vauxn3,
   input vauxp10, input vauxn10,
   input vauxp11, input vauxn11,
   input vp_in,   input vn_in,
   input [1:0] sw,
   output uart_tx,
   output reg [15:0] LED,
   output [7:0] an,
   output dp,
   output [6:0] seg
);

   // -------------------------------------------------------------------------
   // Circuit parameters
   // -------------------------------------------------------------------------
   localparam Vsource   = 3300;   // Supply voltage in mV (3.3V)
   localparam Resistor  = 20000;  // Series resistance in Ohms 

   wire        enable, ready;
   wire [15:0] data;
   reg  [6:0]  Address_in;
   wire [11:0] adc_code;
   assign adc_code = data[15:4];

   // -------------------------------------------------------------------------
   // Display registers
   // -------------------------------------------------------------------------
   reg [31:0] voltage_mv;
   reg [31:0] temp_value;
   reg [3:0]  dig0, dig1, dig2, dig3, dig4, dig5, dig6, dig7;

   // -------------------------------------------------------------------------
   // 16-sample moving average - stable ADC reading
   // -------------------------------------------------------------------------
   reg [11:0] adc_samples [0:15];
   reg [15:0] adc_sum   = 0;
   reg [3:0]  sample_idx = 0;
   reg [11:0] adc_avg   = 0;

   integer i;
   initial begin
      for (i = 0; i < 16; i = i + 1)
         adc_samples[i] = 0;
   end

   always @(posedge CLK100MHZ) begin
      if (ready) begin
         adc_sum              <= adc_sum - adc_samples[sample_idx] + adc_code;
         adc_samples[sample_idx] <= adc_code;
         sample_idx           <= sample_idx + 1;
         adc_avg              <= (adc_sum - adc_samples[sample_idx] + adc_code) >> 4;

         if (adc_avg >= 12'd4093)
            voltage_mv <= 32'd1000;
         else
            voltage_mv <= (adc_avg * 32'd1000) / 32'd4095;

         LED <= {4'b0000, adc_avg};
      end
   end

   // -------------------------------------------------------------------------
   // UART registers
   // -------------------------------------------------------------------------
   wire       uart_ready;
   reg        uart_send  = 1'b0;
   reg [7:0]  uart_data  = 8'd0;
   reg [31:0] uart_timer = 32'd0;
   reg [4:0]  uart_state = 5'd0;
   reg [7:0]  unit_char;

   reg [7:0] snap_d3;   // thousands digit ASCII
   reg [7:0] snap_d2;   // hundreds  digit ASCII
   reg [7:0] snap_d1;   // tens      digit ASCII
   reg [7:0] snap_d0;   // ones      digit ASCII
   reg [7:0] snap_unit; // unit ASCII: 'V','C','R'

   // -------------------------------------------------------------------------
   // XADC instantiation
   // -------------------------------------------------------------------------
   xadc_wiz_0 XLXI_7 (
      .daddr_in(Address_in), .dclk_in(CLK100MHZ),
      .den_in(enable),       .di_in(16'd0),
      .dwe_in(1'b0),         .busy_out(),
      .vauxp2(vauxp2),       .vauxn2(vauxn2),
      .vauxp3(vauxp3),       .vauxn3(vauxn3),
      .vauxp10(vauxp10),     .vauxn10(vauxn10),
      .vauxp11(vauxp11),     .vauxn11(vauxn11),
      .vn_in(vn_in),         .vp_in(vp_in),
      .alarm_out(),          .do_out(data),
      .reset_in(1'b0),       .eoc_out(enable),
      .channel_out(),        .drdy_out(ready)
   );

   // -------------------------------------------------------------------------
   // UART TX instantiation
   // -------------------------------------------------------------------------
   UART_TX_CTRL uart0 (
      .SEND(uart_send), .DATA(uart_data),
      .CLK(CLK100MHZ),  .READY(uart_ready),
      .UART_TX(uart_tx)
   );

   // -------------------------------------------------------------------------
   // XADC channel select
   // -------------------------------------------------------------------------
   always @(*) begin
      Address_in = 7'h1A;
   end

   // -------------------------------------------------------------------------
   // Display value calculation + digit extraction
   // -------------------------------------------------------------------------
   always @(*) begin
      case (sw)
         2'b00: begin
            temp_value = voltage_mv;
            dig0       = 4'hB;
            unit_char  = 8'd86;    // 'V'
         end
         2'b01: begin
            temp_value = (Vsource - voltage_mv) * 1000 / Resistor;
            dig0       = 4'hC;
            unit_char  = 8'd67;    // 'C'
         end
         2'b10: begin
            temp_value = (voltage_mv * Resistor) / (Vsource - voltage_mv);
            dig0       = 4'hD;
            unit_char  = 8'd82;    // 'R'
         end
         default: begin
            temp_value = 32'd0;
            dig0       = 4'hA;
            unit_char  = 8'd63;    // '?'
         end
      endcase

      if (temp_value > 32'd9999)
         temp_value = 32'd9999;

      dig1 = temp_value % 10; temp_value = temp_value / 10;
      dig2 = temp_value % 10; temp_value = temp_value / 10;
      dig3 = temp_value % 10; temp_value = temp_value / 10;
      dig4 = temp_value % 10;
      dig5 = 4'hA;
      dig6 = 4'hA;
      dig7 = 4'hA;
   end

   // -------------------------------------------------------------------------
  
   // -------------------------------------------------------------------------
   always @(posedge CLK100MHZ) begin
      uart_send <= 1'b0;

      // 1-second timer
      if (uart_timer < 32'd100_000_000)
         uart_timer <= uart_timer + 1;
      else begin
         uart_timer <= 32'd0;
         if (uart_state == 0 && uart_ready)
            uart_state <= 1;
      end

      case (uart_state)
         0: begin end   // idle

         1: if (uart_ready) begin
            
               // dig4=thousands, dig3=hundreds, dig2=tens, dig1=ones
               snap_d3   <= dig4 + 8'd48;   // thousands
               snap_d2   <= dig3 + 8'd48;   // hundreds
               snap_d1   <= dig2 + 8'd48;   // tens
               snap_d0   <= dig1 + 8'd48;   // ones
               snap_unit <= unit_char;
               // thousands digit পাঠাও
               uart_data <= dig4 + 8'd48;
               uart_send <= 1'b1;
               uart_state <= 2;
            end

         2: if (uart_ready) begin
               uart_data  <= snap_d2;   // hundreds
               uart_send  <= 1'b1;
               uart_state <= 3;
            end

         3: if (uart_ready) begin
               uart_data  <= snap_d1;   // tens
               uart_send  <= 1'b1;
               uart_state <= 4;
            end

         4: if (uart_ready) begin
               uart_data  <= snap_d0;   // ones
               uart_send  <= 1'b1;
               uart_state <= 5;
            end

         5: if (uart_ready) begin
               uart_data  <= snap_unit; // V / C / R
               uart_send  <= 1'b1;
               uart_state <= 6;
            end

         6: if (uart_ready) begin
               uart_data  <= 8'h0D;    // CR
               uart_send  <= 1'b1;
               uart_state <= 7;
            end

         7: if (uart_ready) begin
               uart_data  <= 8'h0A;    // LF
               uart_send  <= 1'b1;
               uart_state <= 0;
            end

         default: uart_state <= 0;
      endcase
   end

   // -------------------------------------------------------------------------
   // 7-segment display - CLK100MHZ directly
   // -------------------------------------------------------------------------
   DigitToSeg segment1 (
      .in1(dig0), .in2(dig1), .in3(dig2), .in4(dig3),
      .in5(dig4), .in6(dig5), .in7(dig6), .in8(dig7),
      .mclk(CLK100MHZ),
      .an(an), .dp(dp), .seg(seg)
   );

endmodule